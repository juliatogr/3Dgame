#include "Player.h"

Player::Player()
{
	this->pos = Vector3(-1.f, 0.0f, -16.f);
	this->yaw = 180;
	this->pitch = 10;
}
