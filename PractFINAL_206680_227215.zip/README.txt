MIEMBROS DEL EQUIPO:

Mercedes Franchesca Gonzalez
NIA: 206680
email: mercedesfranchesca.gonzalez01@estudiant.upf.edu

Júlia Tortosa
NIA: 227215
email: julia.tortosa01@estudiant.upf.edu

Video de Seguimiento: https://youtu.be/0wuMokrpsD4